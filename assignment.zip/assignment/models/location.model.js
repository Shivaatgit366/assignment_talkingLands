var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var locationSchema = new Schema({
    description: {
        type: String,
    },
    location_name: {
        type: String,
    },
    // location: {
    //     type: {
    //         type: String,
    //         default: 'Point',
    //         enum: ['Point', 'Polygon']
    //     },
    //     coordinates: {
    //         type: [Number],
    //     },
    // },
    location: {
        type: Object
    },
}, {
    timestamps: true
});

module.exports = mongoose.model('location', locationSchema);
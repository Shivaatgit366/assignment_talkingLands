const Location = require('../models/location.model');
const { body } = require("express-validator");


exports.createLocation = [
    body("latlng").isLength({
        min: 1
    }).trim().withMessage("latlng must be specified."),

    async (req, res) => {
        const { latlng } = req.body;
        const [lat, long] = latlng.split(',');

        let location_name = req.body.location_name ? req.body.location_name : "";
        let description = req.body.description ? req.body.description : "";
        let type = req.body.type ? req.body.type : "Point";

        let locationObj = {
            type: type,
            coordinates: [parseFloat(lat), parseFloat(long)]
        }

        try {
            // to save Location;
            const newLocation = await Location.create({
                location_name: location_name,
                description: description,
                location: locationObj
            });

            if (newLocation) {
                res.status(201).json({
                    status: 'success',
                    data: {
                        message: `new location is created`,
                        locationData: newLocation
                    }
                });
            } else {
                res.status(503).json({
                    status: 'fail',
                    data: {
                        message: `unable to create new location`,
                    }
                });
            }
        } catch (err) {
            console.log("err", err);
            res.status(400).json({
                status: 'fail',
                message: 'invalid data sent'
            });
        }
    }
]


exports.getLocations = [
    async (req, res) => {
        try {

            var aggregate = await Location.aggregate([
                {
                    $sort: {
                        "_id": 1,
                    }
                }
            ]);

            return res.status(200).json({
                status: 'success',
                data: {
                    locations: aggregate
                }
            });

        } catch (err) {
            console.log("err", err);
            res.status(400).json({
                status: 'fail',
                message: 'invalid data sent'
            });
        }
    }
]


exports.viewLocation = [

    async (req, res) => {
        const { id } = req.params;

        try {
            // to view location;
            const location = await Location.findOne({
                _id: id,
            });

            if (location) {
                res.status(200).json({
                    status: 'success',
                    data: {
                        location: location
                    }
                });
            } else {
                res.status(503).json({
                    status: 'fail',
                    data: {
                        message: `invalid id`,
                    }
                });
            }
        } catch (err) {
            res.status(400).json({
                status: 'fail',
                message: 'invalid data sent'
            });
        }
    }
]


exports.updateLocation = [

    async (req, res) => {
        try {
            const { id } = req.params;

            const locationObj = await Location.findOne({
                _id: id,
            });

            if (!locationObj) {
                res.status(503).json({
                    status: 'fail',
                    data: {
                        message: `invalid id`,
                    }
                });
            }

            let lat = locationObj.location.coordinates[0];
            let long = locationObj.location.coordinates[1];

            if (req.body.latlng) {
                const { latlng } = req.body;
                let latlongArr = latlng.split(',');
                lat = latlongArr[0];
                long = latlongArr[1];
            }


            let location_name = req.body.location_name ? req.body.location_name : "";
            let description = req.body.description ? req.body.description : "";
            let type = req.body.type ? req.body.type : "Point";

            let locObject = {
                type: type,
                coordinates: [parseFloat(lat), parseFloat(long)]
            }

            // to update Location;
            const updatedLocation = await Location.findByIdAndUpdate(
                { _id: id },
                {
                    location_name: location_name,
                    description: description,
                    location: locObject
                },
                { new: true }
            );

            if (updatedLocation) {
                res.status(200).json({
                    status: 'success',
                    data: {
                        message: `location is updated`,
                        locationData: updatedLocation
                    }
                });
            } else {
                res.status(503).json({
                    status: 'fail',
                    data: {
                        message: `unable to update location`,
                    }
                });
            }
        } catch (err) {
            console.log("err", err);
            res.status(400).json({
                status: 'fail',
                message: 'invalid data sent'
            });
        }
    }
]


exports.deleteLocation = [

    async (req, res) => {
        const { id } = req.params;

        try {
            // to delete location;
            const location = await Location.findOne({
                _id: id,
            });

            if (location) {
                await Location.findByIdAndDelete({ _id: id });

                res.status(200).json({
                    status: 'deleted successfully'
                });
            } else {
                res.status(503).json({
                    status: 'fail',
                    data: {
                        message: `invalid id`,
                    }
                });
            }
        } catch (err) {
            res.status(400).json({
                status: 'fail',
                message: 'invalid data sent'
            });
        }
    }
]


exports.getLocationsForLatlong = [
    body("latlng").isLength({
        min: 1
    }).trim().withMessage("latlng must be specified."),

    async (req, res) => {
        try {
            const { latlng } = req.body;

            let unit = "";
            if (req.body.unit) {
                unit = req.body.unit;
            }

            let latlongArr = latlng.split(',');
            lat = latlongArr[0];
            long = latlongArr[1];

            let type = req.body.type ? req.body.type : "Point";

            var aggregate = await Location.aggregate([
                {
                    $geoNear: {
                        near: {
                            type: type,
                            coordinates: [lat * 1, long * 1]
                        },
                        distanceField: "dist.calculated",
                        maxDistance: 100000,     // within 100000 meters
                        includeLocs: "dist.location",
                        spherical: false
                    }
                },
            ]);

            return res.status(200).json({
                status: 'success',
                data: {
                    locations: aggregate
                }
            });
        } catch (err) {
            console.log("err", err);
            res.status(400).json({
                status: 'fail',
                message: 'invalid data sent'
            });
        }
    }
]

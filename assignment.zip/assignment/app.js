const express = require('express');
const app = express();
const bodyParser = require('body-parser');


// EXPRESS ROUTERS
const locations = require('./routes/locations');


// MIDDLEWARES
// middleware to provide the "request data" in json format.
app.use(bodyParser.urlencoded({ extended: true }));


// ROUTES
app.use('/api/v1/loc', locations);


module.exports = app;
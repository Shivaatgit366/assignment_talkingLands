const express = require('express');
const router = express.Router();

const locations = require('../controllers/location.controllers');


// for locations
router.post('/create-location', locations.createLocation);
router.get('/get-locations', locations.getLocations);
router.get('/get-locations-for-latlong', locations.getLocationsForLatlong);
router.get('/view-location/:id', locations.viewLocation);
router.post('/update-location/:id', locations.updateLocation);
router.delete('/delete-location/:id', locations.deleteLocation);

module.exports = router;